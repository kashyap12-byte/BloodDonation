-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2019 at 03:48 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `bankaddress`
--

CREATE TABLE `bankaddress` (
  `name` varchar(20) NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zip` int(10) NOT NULL,
  `ch` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bankaddress`
--

INSERT INTO `bankaddress` (`name`, `state`, `city`, `zip`, `ch`) VALUES
('RBC Bank', 'Maharashtra (MH)', 'Mumbai City', 400068, '022-28485560'),
('RC Hospital', 'Maharashtra (MH)', 'Mumbai City', 400072, '022-28465560'),
('LIC', 'Maharashtra (MH)', 'Mumbai City', 401107, '022-28587645'),
('Blood Cell', 'Maharashtra (MH)', 'Mumbai City', 400594, '022-28486759'),
('LAMC Bank', 'Maharashtra (MH)', 'Mumbai City', 400068, '022-76589461'),
('Mumbai City Bank', 'Maharashtra (MH)', 'Mumbai City', 401107, '022-56238624'),
('Test0709', 'Maharashtra (MH)', 'Mumbai City', 400072, '022-56126623'),
('SaveLive', 'Maharashtra (MH)', 'Mumbai City', 400579, '022-86132365'),
('LIFE', 'Maharashtra (MH)', 'Mumbai City', 400594, '022-28485673'),
('Blood Bank', 'Maharashtra (MH)', 'Mumbai City', 400068, '022-56323862'),
('MKC Bank', 'Maharashtra (MH)', 'Mumbai City', 400072, '022-28685635'),
('RC Hospital', 'Maharashtra (MH)', 'Mumbai City', 400579, '022-69859635'),
('LIC', 'Maharashtra (MH)', 'Mumbai City', 400579, '022-28256635'),
('LIC', 'Maharashtra (MH)', 'Mumbai City', 401201, '022-28765635'),
('Alliane Unit', 'Maharashtra (MH)', 'Mumbai City', 401202, '022-67579635'),
('Blood Bank', 'Maharashtra (MH)', 'Mumbai City', 401207, '022-76579635'),
('RTG Unit', 'MAHARASHTRA (MH)', 'MUMBAI CITY', 401107, '022-28487965'),
('RTG Unit', 'MAHARASHTRA (MH)', 'MUMBAI CITY', 400068, '022-28487965'),
('RTG Unit', 'MAHARASHTRA (MH)', 'MUMBAI CITY', 400072, '022-28487965'),
('RTG Unit', 'MAHARASHTRA (MH)', 'MUMBAI CITY', 400594, '022-28487965'),
('RTG Unit', 'MAHARASHTRA (MH)', 'MUMBAI CITY', 400067, '022-28487965');

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE `donate` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mh` varchar(20) NOT NULL,
  `bg` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zip` int(10) NOT NULL,
  `contact` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donate`
--

INSERT INTO `donate` (`username`, `name`, `mh`, `bg`, `state`, `city`, `zip`, `contact`) VALUES
('kash12', 'kashyap', 'none', 'a+', 'Maharashtra (MH)', 'Mumbai City', 401107, 8655679544),
('meet12', 'meet', 'None', 'B+', 'Maharashtra (MH)', 'Mumbai City', 400068, 12345);

-- --------------------------------------------------------

--
-- Table structure for table `donatetable`
--

CREATE TABLE `donatetable` (
  `name` varchar(20) NOT NULL,
  `bg` varchar(20) NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `contact` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donatetable`
--

INSERT INTO `donatetable` (`name`, `bg`, `state`, `city`, `contact`) VALUES
('kashyap', 'a+', 'Maharashtra (MH)', 'Mumbai City', 8655679544),
('meet', 'B+', 'Maharashtra (MH)', 'Mumbai City', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL,
  `mmn` varchar(20) DEFAULT NULL,
  `blood_grp` varchar(20) DEFAULT NULL,
  `addres` varchar(50) DEFAULT NULL,
  `contact` varchar(10) DEFAULT NULL,
  `mh` varchar(266) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`username`, `name`, `PASSWORD`, `mmn`, `blood_grp`, `addres`, `contact`, `mh`, `email`) VALUES
('', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('kash12', 'kashyap', 'kash123', 'varsha', 'a+', 'miraroaed', '8655679544', 'none', 'kashyap@gmail.com'),
('meet12', 'meet', 'meet123', 'Arpita', 'B+', 'Borivali', '12345', 'None', 'meet@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `bloodreq` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zip` int(10) NOT NULL,
  `why` varchar(255) NOT NULL,
  `contact` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`username`, `name`, `bloodreq`, `state`, `city`, `zip`, `why`, `contact`) VALUES
('kash12', 'kashyap', 'A+', 'Maharashtra (MH)', 'Mumbai City', 401107, 'medical attention', 8655679544),
('kash12', 'kashyap', 'A+', 'Maharashtra (MH)', 'Mumbai City', 401107, 'medical attention', 8655679544),
('meet12', 'meet', 'B+', 'Maharashtra (MH)', 'Mumbai City', 401107, 'medical attention ', 83434);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `name` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cp` varchar(255) NOT NULL,
  `mmn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`name`, `email`, `username`, `password`, `cp`, `mmn`) VALUES
('kashyap', 'kashyap@gmail.com', 'kash12', 'kash123', 'kash123', 'varsha'),
('meet', 'meet@gmail.com', 'meet12', 'meet123', 'meet123', 'Arpita');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
